<html>
 <head>
  <title>Array</title>
 </head>
 <pre>
 <body>
 <?php
 $cars = array('volvo','BMW','Toyota');
 var_dump($cars);
 ?>
 </pre>
 </body>
  </html>