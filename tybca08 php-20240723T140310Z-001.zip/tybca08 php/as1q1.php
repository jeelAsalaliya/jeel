<html>
 <head>
  <title>1 to 10 hyphen</title>
 </head>
 
 <body>
 <?php
 for($i=1;$i<=10;$i++)
 {
  echo $i;
  
  if($i<10){
  echo "-";
 } }
 ?>
 </body>
 </html>