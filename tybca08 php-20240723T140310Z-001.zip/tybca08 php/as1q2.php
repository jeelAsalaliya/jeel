<html>
 <head>
 <title> 0 - 30 numbers</title>
</head>

<body>
 <?php
 $sum=0;

 
 for($i =0;$i<=30; $i++){
  $sum += $i;
 }
 echo "the sum of all integers between 0 and 30 is: $sum";
 ?>
  
  </body>
 </html>