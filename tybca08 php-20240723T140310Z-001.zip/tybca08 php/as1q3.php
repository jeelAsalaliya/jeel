<html>
 <head>
  <title>pattern</title>
 </head>
 
 <body>
  <?php
  for($i=1;$i<5;$i++)
  {
   for($j=0;$j<$i;$j++)
   {
    echo "*";
}
echo "<br>";
}
  ?>
  </body>
  </html>