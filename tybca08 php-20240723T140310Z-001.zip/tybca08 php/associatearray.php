<html>
 <head>
  <title>Associate Array</title>
 </head>
 
 <body>
 <pre>
  <?php
  $car = array("brand"=>"Ford","model"=>"Mustang","year"=>1964);
  var_dump($car);
  ?>
  
  </pre>
  </body>
  </html>