<html>
 <head> 
  <title>associative array</title>
 </head>
 
 <body>
 <pre>
 <?php
 $car = array("brand"=>"Ford","model"=>"Mustang","year"=>1964);
 echo $car["model"];
 ?>
 </pre>
 </body>
 </html>