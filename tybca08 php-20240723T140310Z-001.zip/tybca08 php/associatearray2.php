<html>
 <head>
  <title> change value array</title>
 </head>
 
 <body>
 <pre>
  <?php
  $car = array("brand"=>"Ford","model"=>"Mustang","year"=>1964);
  $car["year"]=2024;
  var_dump($car);
  ?>
  </pre>
  </body>
  </html>