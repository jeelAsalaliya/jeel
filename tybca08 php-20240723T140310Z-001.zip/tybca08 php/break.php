<html>
 <head>
  <title>Break Statement</title>
 </head>
 
 <body>
  <?php
  for($x=0;$x<=5;$x++){
  if($x==3) break;
  echo "the Number is: $x <br>";
  }
  ?>
  
  </body>
  </html>