<html>
 <head>
  <title> case sensitive </title>
 </head>
 
 <body>
  <?php
  $color= "red";
  echo "my Car is : " .$color. "<br>";
  echo "my house is: " .$Color. "<br>";
  echo "my boat is : ".$COLOR. "<br>";
  
  ?>
  </body>
  </html>