<html>
 <head>
  <title>casting</title>
 </head>
 
 <body>
  <?php
  $a = 5;
  $b = 5.34;
  $c = $a+$b;
  ?>
  </head>
  </html>