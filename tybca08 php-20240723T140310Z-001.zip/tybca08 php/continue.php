<html>
 <head>
  <title>Continue Statement</title>
 </head>
 
 <body>
  <?php
  for($x=0;$x<=10;$x++){
  if($x==3) continue;
  
  echo "The Number is: $x <br>";
  }
  
  ?>
  </body>
  </html>