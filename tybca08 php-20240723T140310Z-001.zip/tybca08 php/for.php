<html>
 <head>
  <title>for loop </title>
 </head>
 
 <body>
  <?php
  for($x=0;$x<=10;$x++){
  echo "The Number is: $x<br>";
  }
  ?>
  
  </body>
  </html>