<html>
 <head>
  <title>xyz assign value same as</title>
 </head>
 
 <body>
 <?php
 $x = $y = $z ="Fruit";
 echo $x;
 echo $y;
 echo $z;
 ?>
 
 </body>
 </html>