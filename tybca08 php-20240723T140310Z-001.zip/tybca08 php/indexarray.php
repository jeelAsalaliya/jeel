<html>
 <head>
  <title>Indexed Array</title>
 </head>
 
 <pre>
 <body>
 <?php
 $cars = array("Volvo","BMW","Toyota");
$cars[1]="Ford";
 var_dump($cars);
 ?>
 
 </body>
 </pre>
 </html>