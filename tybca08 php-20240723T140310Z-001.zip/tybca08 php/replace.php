<html>
 <head>
  <title>replace</title>
  </head>
  
  <body>
   <?php
   $x = "Hello World!";
   echo str_replace("World","Dolly",$x);
   ?>
   
   </body>
   </html>