<html>
 <head>
  <title>reverse</title>
 </head>
 
 <body>
  <?php
  $x = "Hello World!";
  echo strrev($x);
  ?>
  
  </body>
  </html>