<html>
 <head>
  <title>slicing strings</title>
 </head>
 
 <body>
  <?php
  $x = "Hello World!";
  echo substr($x,6,5);
  ?>
  
  </body>
  </html>