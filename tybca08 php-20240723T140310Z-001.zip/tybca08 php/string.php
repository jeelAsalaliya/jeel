<html>
 <head>
  <title>string</title>
 </head>
 
 <body>
  <?php
  $x = "Hello World!";
  $y = 'Hello';
  
  var_dump($x);
  echo "<br>";
  var_dump($y);
  ?>
  
  </body>
  </html>