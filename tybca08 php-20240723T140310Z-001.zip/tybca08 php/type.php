<html>
 <head>
  <title>Type </title>
 </head>
 
 <body>
  <?php
  $x = "html";
  var_dump($x);
  ?>
</body>
</html>