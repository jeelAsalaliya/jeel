<html>
 <head>
  <title> Type </title>
 </head>
 
 <body>
 <pre>
 <?php
 
 var_dump(5); 
 var_dump("john");
 var_dump(3.14);
 var_dump(true);
 var_dump([2,3,56]);
 var_dump(NULL); 
 ?>
 </pre>
 </body>
 </html>