<html>
 <head>
  <title>uppercase</title>
 </head>
 
 <body>
  <?php
  $x = "Hello World!";
  echo strtoupper($x);
  ?>
  </body>
  </html>