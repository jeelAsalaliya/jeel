<html>
 <head>
  <title> variables</title>
 </head>
 
 <body>
 <?php
 $x = 5;
 $y = "john";
 
 echo "$x <br>";
 echo "$y";
 ?>
 </body>
 </html>