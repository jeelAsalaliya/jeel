<html>
 <head>
  <title> add text variable</title>
 </head>
 
 <body>
 <?php
 $txt = "w3schools.com!";
 echo "I Love $txt";
 
 ?>
 </body>
 </html>